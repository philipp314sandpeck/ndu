(function () {
  'use strict';

  var THEMES = {
    hell:   { paper: '#FBFAF6', ink: '#1B1A16', inkSoft: '#6E6A5E', rule: '#DFDACB', accent: '#8C2F1E', chrome: '#F3F0E7', shadow: 'rgba(27,26,22,.14)' },
    sepia:  { paper: '#F5EDDD', ink: '#33291C', inkSoft: '#7A6A52', rule: '#DFCFB2', accent: '#8A4218', chrome: '#EDE2CC', shadow: 'rgba(51,41,28,.16)' },
    dunkel: { paper: '#15171B', ink: '#E7E4DC', inkSoft: '#9A968C', rule: '#2E3239', accent: '#E0876A', chrome: '#1C1F25', shadow: 'rgba(0,0,0,.5)' }
  };

  var CHAPTERS = [
    'Deckblatt', 'Einleitung: Gestaltung als Prozess', 'Was ist die ISO 9241-210?', 'Grundbegriffe',
    'Vorteile des HCD-Prozesses', 'Die sechs Grundsätze', 'Gestaltungskreislauf und vier Aktivitäten',
    'Das interdisziplinäre Gestaltungsteam', 'Nachhaltigkeit als Teil der Norm',
    'Design Thinking im Vergleich', 'Die Norm auf einen Blick', 'Quellenverzeichnis'
  ];

  var STORAGE_KEY = 'iso9241-ereader-v1';

  var app = document.getElementById('app');
  var reader = app.querySelector('[data-reader]');
  var sections = Array.prototype.slice.call(app.querySelectorAll('[data-ch]'));
  var bar = app.querySelector('[data-bar]');
  var runningTitle = app.querySelector('[data-running-title]');
  var scrim = app.querySelector('[data-scrim]');
  var tocPanel = app.querySelector('[data-panel="toc"]');
  var settingsPanel = app.querySelector('[data-panel="settings"]');

  var cur = 0;
  var panel = null;
  var saveTimer = null;

  var prefs = { theme: 'hell', fs: 19, lh: 1.62, font: 'serif' };

  function load() {
    var savedScroll = 0;
    try {
      var saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
      if (saved.prefs) Object.assign(prefs, saved.prefs);
      savedScroll = saved.scroll || 0;
    } catch (e) {}
    return savedScroll;
  }

  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        scroll: reader.scrollTop,
        prefs: prefs
      }));
    } catch (e) {}
  }

  function applyPrefs() {
    var t = THEMES[prefs.theme] || THEMES.hell;
    var s = document.documentElement.style;
    s.setProperty('--paper', t.paper);
    s.setProperty('--ink', t.ink);
    s.setProperty('--ink-soft', t.inkSoft);
    s.setProperty('--rule', t.rule);
    s.setProperty('--accent', t.accent);
    s.setProperty('--chrome', t.chrome);
    s.setProperty('--shadow', t.shadow);
    s.setProperty('--fs', prefs.fs + 'px');
    s.setProperty('--lh', String(prefs.lh));
    s.setProperty('--ff-body', prefs.font === 'sans'
      ? "'Archivo',system-ui,sans-serif"
      : "'Newsreader',Georgia,serif");
    document.body.style.background = t.paper;

    mark('[data-theme]', 'data-theme', prefs.theme);
    mark('[data-font]', 'data-font', prefs.font);
    mark('[data-lh]', 'data-lh', prefs.lh);
    highlightToc();
  }

  function mark(sel, attr, val) {
    app.querySelectorAll(sel).forEach(function (b) {
      b.classList.toggle('is-active', b.getAttribute(attr) === String(val));
    });
  }

  function goTo(n) {
    n = Math.max(0, Math.min(sections.length - 1, n));
    var sec = sections[n];
    if (!sec) return;
    var top = reader.scrollTop + sec.getBoundingClientRect().top
      - reader.getBoundingClientRect().top - 16;
    reader.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
  }

  function updateCurrent() {
    var base = reader.getBoundingClientRect().top + 90;
    var idx = 0;
    sections.forEach(function (s, i) {
      if (s.getBoundingClientRect().top <= base) idx = i;
    });
    if (idx === cur) return;
    cur = idx;
    if (runningTitle) {
      runningTitle.textContent = idx === 0 ? 'Menschzentrierte Gestaltung' : CHAPTERS[idx];
    }
    highlightToc();
  }

  function highlightToc() {
    app.querySelectorAll('[data-toc] [data-goto]').forEach(function (b) {
      var on = Number(b.getAttribute('data-goto')) === cur;
      b.classList.toggle('is-active', on);
    });
  }

  function togglePanel(name) {
    panel === name ? closePanel() : openPanel(name);
  }

  function openPanel(name) {
    panel = name;
    if (name === 'toc') tocPanel.classList.add('is-open');
    if (name === 'settings') settingsPanel.classList.add('is-open');
    scrim.classList.add('is-active');
  }

  function closePanel() {
    panel = null;
    tocPanel.classList.remove('is-open');
    settingsPanel.classList.remove('is-open');
    scrim.classList.remove('is-active');
  }

  app.addEventListener('click', function (e) {
    var g = e.target.closest('[data-goto]');
    if (g) { goTo(Number(g.getAttribute('data-goto'))); closePanel(); return; }

    var a = e.target.closest('[data-act]');
    if (a) {
      var act = a.getAttribute('data-act');
      if (act === 'toc') togglePanel('toc');
      else if (act === 'settings') togglePanel('settings');
      else if (act === 'close') closePanel();
      return;
    }

    var set = e.target.closest('[data-theme],[data-fs],[data-lh],[data-font]');
    if (set) {
      if (set.hasAttribute('data-theme')) prefs.theme = set.getAttribute('data-theme');
      if (set.hasAttribute('data-font')) prefs.font = set.getAttribute('data-font');
      if (set.hasAttribute('data-lh')) prefs.lh = Number(set.getAttribute('data-lh'));
      if (set.hasAttribute('data-fs')) {
        prefs.fs = Math.max(15, Math.min(26, prefs.fs + Number(set.getAttribute('data-fs'))));
      }
      applyPrefs();
      save();
    }
  });

  scrim.addEventListener('click', closePanel);

  reader.addEventListener('scroll', function () {
    var max = reader.scrollHeight - reader.clientHeight;
    var pct = max > 12 ? Math.min(100, Math.max(0, (reader.scrollTop / max) * 100)) : 0;
    if (bar) bar.style.width = pct.toFixed(1) + '%';
    updateCurrent();
    if (!saveTimer) saveTimer = setTimeout(function () { saveTimer = null; save(); }, 600);
  }, { passive: true });

  window.addEventListener('keydown', function (e) {
    if (e.target && /input|textarea/i.test(e.target.tagName)) return;
    if (e.key === 'ArrowRight') { e.preventDefault(); goTo(cur + 1); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); goTo(cur - 1); }
    else if (e.key === 'Escape') closePanel();
  });

  var savedScroll = load();
  applyPrefs();
  if (savedScroll) reader.scrollTop = savedScroll;
  reader.dispatchEvent(new Event('scroll'));
})();
