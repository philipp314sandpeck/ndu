# Menschzentrierte Gestaltung nach ISO 9241-210

*Lernskript zur menschzentrierten Gestaltung interaktiver Systeme*

## 1. Einleitung: Gestaltung als Prozess

Ein Interface stellt selten nur eine Anordnung von Bedienelementen dar, sondern das Ergebnis einer Reihe von Entscheidungen darüber, wie ein System von seinen Nutzenden verstanden und bedient werden kann. Damit dieses Ergebnis nicht dem Zufall überlassen bleibt, sondern nachvollziehbar und wiederholbar entsteht, wurde mit der ISO 9241-210 ein internationaler Standard für die menschzentrierte Gestaltung interaktiver Systeme geschaffen.

Die Norm formuliert dabei keine Vorgaben zur konkreten Gestaltung von Oberflächen. Sie beschreibt vielmehr, welchem Vorgehen eine Gestaltung folgen sollte, damit das Ergebnis den Bedürfnissen der Nutzenden gerecht wird – unabhängig davon, ob am Ende eine Anwendung, eine Website oder ein technisches Terminal steht. Das vorliegende Lernskript führt in die zentralen Begriffe, Grundsätze und Aktivitäten der Norm ein und ordnet sie in den breiteren Kontext nutzerzentrierter Gestaltungsmethoden ein.

## 2. Was ist die ISO 9241-210?

Die ISO 9241-210 trägt den offiziellen Titel „Ergonomie der Mensch-System-Interaktion – Teil 210: Prozess zur Gestaltung gebrauchstauglicher interaktiver Systeme“. Sie wurde 2010 als Nachfolgerin der älteren ISO 13407:1999 veröffentlicht, 2011 als deutsche Fassung DIN EN ISO 9241-210 übernommen und 2019 international überarbeitet. Sie ist Teil einer umfassenden Normenfamilie, deren Teile jeweils nach einem „Hunderter-System“ sortiert sind:

| Nummernbereich | Thema |
| --- | --- |
| 100 | Software-Ergonomie |
| 200 | Prozesse der Mensch-System-Interaktion (hier: Teil 210) |
| 300 | Anzeigen und anzeigebezogene Hardware |
| 400 | Physikalische Eingabegeräte |
| 500–700 | Arbeitsplatz- und Umgebungsergonomie, Leitzentralen |

Der Geltungsbereich ist bewusst weit gefasst: Die Norm richtet sich an alle, die „rechnergestützte interaktive Systeme“ planen und gestalten – vom Verkaufsautomaten über Bankprozesse bis zu Webseiten, Anwendungen und Consumer-Geräten. Sie beschreibt dabei keine konkreten Gestaltungslösungen oder Styleguides, sondern einen übergeordneten Rahmen aus Grundsätzen und Aktivitäten, der sich in nahezu jedes Vorgehensmodell einbetten lässt – unabhängig davon, ob ein klassisches Wasserfallmodell oder ein agiles Vorgehen zugrunde liegt.

## 3. Grundbegriffe

Die Norm definiert ihre Begriffe präzise. Die vier wichtigsten:

| Begriff | Definition laut Norm | Beispiel |
| --- | --- | --- |
| **Nutzungskontext** | „Benutzer, Arbeitsaufgaben, Ausrüstung (Hardware, Software, Materialien) sowie physische und soziale Umgebung, in der das Produkt genutzt wird“ | Eine Pflegekraft, die im Stehen, mit Handschuhen und unter Zeitdruck ein Tablet bedient – andere Bedingungen als am Büroschreibtisch |
| **Menschzentrierte Gestaltung** | Herangehensweise, die Systeme gebrauchstauglicher macht, indem sie sich auf die Nutzung konzentriert und Wissen aus Ergonomie und Usability einbezieht | Nicht „Was lässt sich technisch umsetzen?“, sondern „Was benötigt die nutzende Person, um ihr Ziel zu erreichen?“ |
| **Gebrauchstauglichkeit (Usability)** | Ausmaß, in dem ein System von bestimmten Nutzern in einem bestimmten Kontext genutzt werden kann, um Ziele **effektiv, effizient und zufriedenstellend** zu erreichen | Ein Self-Checkout, an dem 95 % der Kundschaft ohne Hilfe bezahlt (effektiv), in unter 90 Sekunden (effizient) und ohne Verdruss (zufriedenstellend) |
| **User Experience (UX)** | „Wahrnehmungen und Reaktionen einer Person, die aus der tatsächlichen und/oder erwarteten Benutzung eines Produkts, Systems oder einer Dienstleistung resultieren“ | Relevant ist nicht nur, ob eine Funktion technisch korrekt arbeitet, sondern wie sich die gesamte Interaktion anfühlt – vor, während und nach der Nutzung |

Zu unterscheiden ist insbesondere zwischen Usability und User Experience: Usability ist **messbar** (effektiv, effizient, zufriedenstellend), User Experience ist **umfassender** und schließt Emotionen, Erwartungen und das Markenerlebnis mit ein. Ein System kann im engeren Sinn gebrauchstauglich sein und dennoch eine unbefriedigende User Experience erzeugen – etwa dann, wenn es zwar funktioniert, sich jedoch distanziert, bevormundend oder unseriös anfühlt.

## 4. Vorteile des Human Centered Design Prozesses

Menschzentrierte Gestaltung erscheint zunächst als Umweg – zusätzliche Interviews, Prototypen und Tests, bevor überhaupt final gestaltet wird. Die Norm selbst begründet, warum sich dieser Umweg auszahlt. Gebrauchstaugliche Systeme:

1. steigern die Produktivität der Nutzenden und die Wirtschaftlichkeit von Organisationen;
2. senken Schulungs- und Betreuungskosten, weil sie leichter verstanden werden;
3. erhöhen die Zugänglichkeit für Menschen mit unterschiedlichen Fähigkeiten;
4. verbessern die User Experience und reduzieren Stress;
5. verschaffen einen Wettbewerbsvorteil, etwa durch Markenschärfung;
6. tragen zu Nachhaltigkeitszielen bei.

Besonders praxisrelevant ist ein Befund, der sich durch die gesamte Norm zieht: Je früher ein Problem entdeckt wird, desto günstiger lässt es sich beheben. „Vorgeschlagene Änderungen aufgrund einer frühzeitigen Evaluierung sind wahrscheinlich am kostengünstigsten“. Ein Klickpfad, der bereits im Wireframe fehlerhaft angelegt ist, lässt sich in wenigen Minuten korrigieren. Derselbe Fehler, erst nach der Markteinführung entdeckt, verursacht Entwicklungsaufwand, Supportanfragen und im ungünstigsten Fall den Verlust von Nutzenden.

Als Praxisbeispiel lässt sich anführen, dass viele im Alltag als frustrierend empfundene digitale Angebote – etwa Formulare ohne verständliche Fehlermeldungen oder Navigationsstrukturen, die das Erreichen eines Ziels erschweren – selten auf mangelndes gestalterisches Talent zurückzuführen sind. Häufiger liegt die Ursache in einem fehlenden oder verkürzten menschzentrierten Prozess, in dessen Rahmen die tatsächlichen Bedürfnisse der Nutzenden nie systematisch erhoben wurden.

## 5. Die sechs Grundsätze der menschzentrierten Gestaltung

Unabhängig vom gewählten Vorgehensmodell nennt die Norm sechs Grundsätze, die jeder menschzentrierte Ansatz erfüllen sollte. Zur Veranschaulichung eignet sich ein einfaches, nicht-digitales Beispiel: die Gestaltung einer Tür.

1. **Verständnis von Nutzern, Aufgaben und Umgebungen.** Eine einfache Haustür erfordert andere Anforderungen als eine Schiebetür im Krankenhaus (Hygiene, Bahrentransport, freie Hände) oder eine Sicherheitstür (Einbruchschutz). Ohne Kontextverständnis wird höchstwahrscheinlich die falsche Tür für den falschen Ort hergestellt.
2. **Aktive Einbeziehung der Nutzenden.** Nicht nur über Pflegekräfte sprechen, sondern gemeinsam mit ihnen an der Tür-Bedienung arbeiten – sie kennen Griffhöhen, Zeitdruck und verschmutzte Hände aus eigener Erfahrung.
3. **Verfeinerung durch nutzerzentrierte Evaluierung.** Ein erster Türentwurf wird an tatsächlichen Nutzenden getestet, Rückmeldungen fließen in die überarbeitete Version ein.
4. **Iteratives Vorgehen.** Die „richtige“ Tür entsteht selten im ersten Anlauf – Anforderungen zeigen sich oft erst, wenn ein erster Entwurf vorliegt und darauf reagiert wird.
5. **Berücksichtigung der gesamten User Experience.** Es zählt nicht nur, ob die Tür aufgeht, sondern auch das Geräusch, das Gefühl von Sicherheit oder Zuverlässigkeit, das sie vermittelt.
6. **Multidisziplinäre Teams.** Statik, Brandschutz, Design, Herstellung und Nutzerperspektive müssen zusammenkommen – ebenso wie bei einem digitalen Interface Entwicklung, Content, visuelle Gestaltung und UX-Research zusammenspielen müssen.

Dasselbe Prinzip gilt für digitale Interfaces in vergleichbarer Weise: Ein Login-Formular für eine Banking-Anwendung erfordert andere Anforderungen als eines für ein Videospiel – auch wenn beide technisch betrachtet „nur“ ein Formular darstellen. Ein Videochat-Interface, das im privaten Umfeld hervorragend funktioniert, kann sich im professionellen Meeting-Kontext als ungeeignet erweisen (vgl. Jendryschik, 2020) – der Kontext entscheidet, nicht die Technik allein.

## 6. Der Gestaltungskreislauf und seine vier Hauptaktivitäten

Das Herzstück der Norm sind vier miteinander verbundene Aktivitäten, die iterativ – also wiederholt und sich gegenseitig beeinflussend – durchlaufen werden:

![iso-9241-210-design-aktivitaeten (1).png](blob/ac060cde-48d3)**Nutzungskontext verstehen**: Wer nutzt das System, mit welchem Ziel, in welcher Umgebung? Typische Methoden sind Interviews, Contextual Inquiry, Beobachtung und Personas.

**Nutzungsanforderungen spezifizieren**: Aus den Erkenntnissen werden prüfbare Anforderungen abgeleitet. Das Requirements Engineering unterscheidet dabei klassischerweise drei Arten von Anforderungen: funktionale Anforderungen, die festlegen, was ein System leisten soll (z. B. „Das System muss eine Rechnungskorrektur ermöglichen“); Qualitätsanforderungen, die messbare Qualitätsaspekte wie Leistung, Verfügbarkeit oder Sicherheit betreffen (z. B. „90 % der Nutzenden sollen einen Rechnungseinspruch in unter drei Minuten abschließen können“); sowie Constraints (Randbedingungen), die den Lösungsraum zusätzlich eingrenzen, etwa durch gesetzliche Vorgaben oder vorgegebene Technologien. Die ISO 9241-210 spricht in diesem Zusammenhang insbesondere von Gebrauchstauglichkeitsanforderungen mit messbaren Zielen, die sich der Kategorie der Qualitätsanforderungen zuordnen lassen.

**Gestaltungslösungen entwerfen**: Vom groben Wireframe über Klick-Dummys bis zum High-Fidelity-Prototypen – je einfacher der Prototyp, desto günstiger lassen sich noch Alternativen verwerfen. In der Praxis kommen hierfür häufig digitale Prototyping-Werkzeuge zum Einsatz, die einen raschen Wechsel zwischen Entwurf, Test und Überarbeitung ermöglichen.

![Wireframes Prototyping Websites.png](blob/14e866d3-30ec)**Design evaluieren**: Prüfung durch tatsächliche Nutzende (Usability-Tests, Think-Aloud) oder inspektionsbasiert durch Fachpersonen anhand von Heuristiken und Checklisten. Die Norm ist hier eindeutig: Rein expertenbasierte Bewertungen ersetzen keine echten Nutzertests, wenn es um Akzeptanz und Aufgabentauglichkeit geht.

Wichtig ist die Rückkopplung: Erfüllt die Lösung die Anforderungen nicht, beginnt der Kreislauf erneut – mit den neuen Erkenntnissen aus der Evaluierung. Iteration ist damit kein Zeichen von Scheitern, sondern der Kern des Prozesses selbst.

## 7. Das interdisziplinäre Gestaltungsteam

Die Norm hält fest, dass ein menschzentriertes Team nicht groß sein muss, aber „ausreichend vielfältig besetzt“ sein sollte. Genannt werden unter anderem Kompetenzen aus Ergonomie/Usability, Fachwissen der Anwendungsdomäne, visuelle Gestaltung, technische Dokumentation sowie System- und Softwaretechnik. In der Praxis übersetzt sich das in konkrete Rollen (unvollständige Liste, je nach Projekttyp variierend):

| Rolle | Beitrag zum Prozess |
| --- | --- |
| UX-Researcher | Research, Interviews, Audits |
| Requirements Engineer | Anforderungen erheben und dokumentieren |
| UX-Designer:in | Informationsarchitektur, Wireframes |
| UI-Designer:in | Visuelles Interface- und Interaktionsdesign |
| Usability Engineer | Testing/Evaluierung und Validierung |
| Content-/UX-Copywriter:in | Texte, Mikrocopy, Inhalte |
| Software Engineer/Developer | Technische Umsetzung |
| Projektmanager | Prozessbegleitung und -steuerung |

Der Grund dafür ist einfach: Die Entwicklung von Websites und Anwendungen ist eine Ingenieursleistung mehrerer Disziplinen. Kaum eine einzelne Person kann gleichzeitig Nutzerbedürfnisse erheben, eine Informationsarchitektur planen, visuell gestalten und die technische Umsetzung verantworten – und selbst wenn, würde die fehlende Außenperspektive blinde Flecken erzeugen. Interdisziplinäre Zusammenarbeit ist daher kein organisatorischer Zusatz, sondern integraler Bestandteil menschzentrierter Gestaltung.

## 8. Nachhaltigkeit als Teil der Norm

Seit der Überarbeitung 2010 enthält die Norm einen eigenen Abschnitt zu Nachhaltigkeit. Menschzentrierte Gestaltung unterstützt laut Norm direkt zwei der drei Nachhaltigkeits-Säulen: die **ökonomische** (weniger Fehlentwicklungen, höhere Akzeptanz, geringere Ablehnung durch Nutzende) und die **soziale** (bessere Gesundheit, Wohlbefinden und Teilhabe, auch für Menschen mit Behinderungen). Der zugrunde liegende Gedanke: Systeme, die tatsächlich gebrauchstauglich sind, werden länger genutzt, seltener abgelehnt und seltener vorzeitig ersetzt – dies ist nicht nur gute Gestaltung, sondern auch Ressourcenschonung.

## 9. Design Thinking und ISO 9241-210 im Vergleich

Wer sich mit Innovations- und Produktentwicklung beschäftigt, ist mit hoher Wahrscheinlichkeit bereits mit dem Ansatz des **Design Thinking** in Berührung gekommen. Ein Vergleich mit der menschzentrierten Gestaltung nach ISO 9241-210 lohnt sich, da beide Ansätze aus einem verwandten ideengeschichtlichen Kontext stammen – beide gehen unter anderem auf Herbert A. Simons Arbeiten zu einer Methodologie des Gestaltens („The Sciences of the Artificial“, 1969) zurück – und strukturelle Parallelen aufweisen.

![Design-Thinking-Prozess.jpg](blob/973d024e-4a35)Design Thinking wird üblicherweise in sechs Phasen gegliedert: Verstehen, Beobachten (Empathie), Standpunkte definieren, Ideen generieren, Prototyping und Testen. Diese Phasen lassen sich den Aktivitäten der ISO 9241-210 annähernd zuordnen:

| Aktivität nach ISO 9241-210 | Phase im Design Thinking |
| --- | --- |
| Feststellen der Notwendigkeit einer menschzentrierten Gestaltung | – (im Design Thinking nicht vorgesehen) |
| Nutzungskontext verstehen | Verstehen / Beobachten |
| Nutzungsanforderungen spezifizieren | Standpunkte definieren |
| Gestaltungslösungen entwerfen | Ideen generieren / Prototyping |
| Design evaluieren | Testen (Iterieren) |
| Langfristige Prüfung im realen Nutzungskontext | – (im Design Thinking nicht vorgesehen) |

Beide Ansätze teilen zentrale Merkmale: Sie sind iterativ angelegt, stellen die Bedürfnisse realer Nutzender in den Mittelpunkt, setzen früh auf Prototypen und akzeptieren Scheitern als integralen Bestandteil des Prozesses – ein erster Entwurf gilt in beiden Modellen nie als fertige Lösung.

Die Unterschiede liegen vor allem im Geltungsbereich und in der Prozesstiefe: Design Thinking ist als generische Methode domänenoffen konzipiert und wird nicht nur zur Gestaltung interaktiver Systeme, sondern auch für organisatorische Innovation oder soziale Problemstellungen eingesetzt; die Frage, ob ein nutzerzentriertes Vorgehen überhaupt angemessen ist, stellt sich dabei kaum. Die ISO 9241-210 hingegen ist explizit auf interaktive Systeme zugeschnitten und sieht sowohl einen expliziten Ausgangspunkt (Klärung der Notwendigkeit) als auch einen expliziten Endpunkt in Form einer langfristigen Prüfung im realen Betrieb vor – ein Element, das im Design-Thinking-Prozess, der vor der finalen Implementierung endet, nicht enthalten ist. Zudem trennt Design Thinking die Ideengenerierung formal stärker von der Prototypenerstellung, während die ISO 9241-210 beide Schritte einer gemeinsamen Aktivität zuordnet.

## 10. Die Norm auf einen Blick

- ISO 9241-210 beschreibt keine Gestaltungslösungen, sondern einen **Prozess**: wie menschzentrierte interaktive Systeme entstehen.
- Kern sind **sechs Grundsätze** (Kontextverständnis, Nutzereinbezug, evidenzbasierte Verfeinerung, Iteration, ganzheitliche User Experience, multidisziplinäres Team).
- Der Prozess besteht aus **vier sich wiederholenden Aktivitäten**: Nutzungskontext verstehen → Anforderungen spezifizieren → Gestaltungslösungen entwerfen → evaluieren – und bei Bedarf erneut von vorne.
- Menschzentrierte Gestaltung ist **ökonomisch und sozial** begründet: Je früher Probleme entdeckt werden, desto günstiger ist die Korrektur.
- Der Prozess erfordert **interdisziplinäre Teams**, keine Einzelleistung.
- **Design Thinking** verfolgt einen strukturell verwandten, aber domänenoffenen Ansatz und kann als ergänzende Perspektive dienen, insbesondere in frühen, explorativen Projektphasen.
- Der Prozess ist kein Formular zum Abhaken, sondern eine Denkhaltung: Jede Gestaltungsentscheidung sollte danach geprüft werden, wessen Bedürfnis sie tatsächlich erfüllt.

## Quellenverzeichnis

**Norm (Primärquelle)**

- DIN EN ISO 9241-210:2011-01: *Ergonomie der Mensch-System-Interaktion – Teil 210: Prozess zur Gestaltung gebrauchstauglicher interaktiver Systeme (ISO 9241-210:2010)*. Berlin: Beuth Verlag.
- ISO 13407:1999: *Human-centred design processes for interactive systems*. Genf: International Organization for Standardization.
- [ISO 9241-210:2019 – Ergonomics of human-system interaction – Part 210: Human-centred design for interactive systems](https://www.iso.org/standard/77520.html). ISO.

**Weiterführende Fachliteratur**

- Burghardt, M., Heckner, M., Kattenbeck, M., Schneidermeier, T. & Wolff, C. (2011): *Design Thinking = Human-centered Design?* Lehrstuhl für Medieninformatik / Lehrstuhl für Informationswissenschaft, Universität Regensburg.
- Plattner, H., Meinel, C. & Weinberg, U. (2009): *Design Thinking*. München: mi-Wirtschaftsbuch.
- Brown, T. & Katz, B. (2009): *Change by Design – How Design Thinking Transforms Organizations and Inspires Innovation*. New York: Harper Collins.
- Norman, Donald A. (1998): *The Design of Everyday Things*. New York: Basic Books.
- Krug, Steve (2014): *Don’t Make Me Think – A Common Sense Approach to Web Usability*. Berkeley: New Riders.
- Hartson, Rex & Pyla, Pardha (2012): *The UX Book – Process and Guidelines for Ensuring a Quality User Experience*. Amsterdam: Morgan Kaufmann.
- Sarodnick, Florian & Brau, Henning (2016): *Methoden der Usability Evaluation – Wissenschaftliche Grundlagen und praktische Anwendung*. Bern: Hogrefe.

**Online-Quellen (zuletzt geprüft September 2026)**

- Jendryschik, Michael (2020): [Grundsätze der menschzentrierten Gestaltung – ein Blick in die DIN EN ISO 9241-210](https://jendryschik.de/weblog/2020/08/22/grundsaetze-der-menschzentrierten-gestaltung-ein-blick-in-die-din-en-iso-9241-210).
- eresult GmbH (2024): [UX-Design-Prozess – 6 Schritte nach ISO 9241-210 erklärt](https://www.eresult.de/blog/ux-design/ux-design-prozess/).
- Rheinwerk Computing: [How to „Do“ UX Design: A Guide to the ISO 9241-210 Standard](https://blog.rheinwerk-computing.com/how-to-do-ux-design-a-guide-to-the-iso-9241-210-standard).
- ISO (International Organization for Standardization): [ISO 9241-210:2019, Produktseite](https://www.iso.org/standard/77520.html).
